package com.example.dontp.pets;

/**
 * Created by dontp on 22/05/2016.
 */
public class Pets2 {
    private int mascotasId;
    private int mascotasLike;

    public Pets2(int mascotasId, int mascotasLike) {
        this.mascotasId = mascotasId;
        this.mascotasLike = mascotasLike;
    }

    public int getMascotasId() {
        return mascotasId;
    }

    public void setMascotasId(int mascotasId) {
        this.mascotasId = mascotasId;
    }

    public int getMascotasLike() {
        return mascotasLike;
    }

    public void setMascotasLike(int mascotasLike) {
        this.mascotasLike = mascotasLike;
    }
}
